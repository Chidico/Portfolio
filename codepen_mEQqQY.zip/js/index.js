$('body').scrollspy({target: ".navbar"});

function scrollWin(x,y) {
    window.scrollBy(0,0);
}
$(document).ready(function() {
    });